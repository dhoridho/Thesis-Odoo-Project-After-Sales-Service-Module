{
    "name": "Test Case Akasha Wira",
    "summary": "Addonstest",
    "author": "Ridho",
    "depends": [

    ],
    "data": [
        "security/ir.model.access.csv",
        "views/main_model_view.xml",
        "views/state_state_view.xml",
        "wizards/main_wizard_views.xml",

    ],

    "application": True,
    "installable": True,
    "auto_install": False,
}
